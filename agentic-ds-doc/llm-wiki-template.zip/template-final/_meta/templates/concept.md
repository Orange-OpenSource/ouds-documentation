---
type: concept
tags:
  - 
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
sources: []
related: []
---

## Définition

## Développement

## ⚡ Tensions / Contradictions

## Connexions

→ Voir aussi : 
