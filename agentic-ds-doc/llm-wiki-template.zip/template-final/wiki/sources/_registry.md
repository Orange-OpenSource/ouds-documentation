---
type: index
tags:
  - registry
  - sources
  - deduplication
created: AAAA-MM-JJ
updated: AAAA-MM-JJ
---

## Registre des sources ingérées

Ce fichier est maintenu automatiquement par Claude lors de chaque INGEST et VEILLE. Il liste toutes les sources déjà ingérées dans le vault afin d'éviter les doublons. **Ne pas modifier manuellement les lignes de la table.**

> Pour chaque veille, ce registre est lu en Phase 0. Toute URL déjà présente est marquée `[DÉJÀ INGÉRÉE]` dans le rapport et exclue de l'ingestion.

| Fiche source | Titre | URL | Date d'ingestion |
|---|---|---|---|
