---
type: log
updated: 2026-06-17
---

# Journal du Wiki

> Fichier append-only. Ne jamais modifier les entrées passées. Ajouter uniquement en bas.
> Format des entrées : `## [AAAA-MM-JJ] <type> | <titre>`
> Types : `ingest` | `query` | `lint` | `veille` | `gap` | `init`

---

## [2026-06-17] init | Vault créé

Structure initiale générée. Domaine à définir.
Pages créées : [[index]], [[overview]], ce fichier.
Note : vault vide, prêt pour les premières ingestions.
