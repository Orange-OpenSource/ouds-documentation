---
type: log
updated: AAAA-MM-JJ
---

# Journal du Wiki

> Fichier append-only. Ne jamais modifier les entrées passées. Ajouter uniquement en bas.
> Format des entrées : `## [AAAA-MM-JJ] <type> | <titre>`
> Types : `ingest` | `query` | `lint` | `veille` | `gap` | `init`

---

## [AAAA-MM-JJ] init | Initialisation du vault
Pages touchées : [[index]], [[overview]], [[log]]
Note : Structure vierge créée. Domaine à définir.
