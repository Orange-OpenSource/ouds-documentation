---
type: synthesis
tags:
  - overview
created: AAAA-MM-JJ
updated: AAAA-MM-JJ
sources: []
related: []
---

## Vue d'ensemble

> Synthèse générale du domaine. Mise à jour par Claude à chaque ingest qui modifie l'image globale.
> 2 à 4 pages. Prose continue.

*(à remplir lors du premier ingest)*
